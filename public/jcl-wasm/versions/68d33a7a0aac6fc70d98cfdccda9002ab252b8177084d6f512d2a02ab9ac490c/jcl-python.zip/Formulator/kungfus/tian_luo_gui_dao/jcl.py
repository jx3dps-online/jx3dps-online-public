def patch_parser(file_path: str, parser):
    """Replay confirmed trigger grants at their exact event before DOT snapshots."""
    try:
        with open(file_path, encoding="gbk") as file:
            lines = file.readlines()
    except UnicodeDecodeError:
        with open(file_path, encoding="utf-8") as file:
            lines = file.readlines()
    from utils.lua import parse_lua
    if not any(player.kungfu_id == 10225 for player in getattr(parser, "players", {}).values()) and not any(
        row[4] == "4" and parse_lua(row[-1])[3] == 10225
        for row in (line.split("\t") for line in lines)
    ):
        return
    pending, confirmed = {}, {}
    event = 0
    for line in lines:
        row = line.split("\t")
        if row[4] not in ("13", "21"):
            continue
        detail, frame = parse_lua(row[-1]), int(row[1])
        owner = detail[0]
        if row[4] == "21":
            event += 1
            if detail[2] != 0:
                continue
            if detail[4] == 22169 and detail[1] == owner:
                pending[(owner, 15455)] = dict(event=event, frame=frame, grant=None, proof=None)
            elif detail[4] == 27287:
                pending[(owner, 3316)] = dict(event=event, frame=frame, grant=None, proof=None)
            continue
        for buff_id, proof_id in ((15455, 15456), (3316, 3453)):
            trigger = pending.get((owner, buff_id))
            if trigger is None or frame < trigger["frame"]:
                continue
            active = int(detail[6]) > frame
            if detail[4] == buff_id and detail[5] == 1 and active:
                if detail[8] in ((1, 2) if buff_id == 15455 else (1,)):
                    trigger["grant"] = (detail[8], int(detail[6]), frame)
            elif detail[4] == proof_id and detail[8] == 1 and active:
                if detail[5] == (1 if buff_id == 15455 else 0):
                    trigger["proof"] = frame
            grant, proof = trigger["grant"], trigger["proof"]
            if grant and proof is not None and (
                proof == grant[2] if buff_id == 15455 else proof <= grant[2]
            ):
                confirmed[trigger["event"]] = (owner, buff_id, *grant[:2])
                pending.pop((owner, buff_id))

    original_parse_damage = parser.parse_damage
    event = 0

    def parse_damage(row):
        nonlocal event
        event += 1
        grant = confirmed.get(event)
        if grant:
            owner, buff_id, level, end_frame = grant
            player = parser.players.get(owner)
            if player and player.kungfu_id == 10225:
                parser.buff_stacks[owner].pop(buff_id, None)
                parser.buff_intervals[owner].pop(buff_id, None)
                parser.buff_stacks[owner][buff_id][level] = 1
                parser.buff_intervals[owner][buff_id][level] = end_frame
        return original_parse_damage(row)

    parser.parse_damage = parse_damage
    _patch_channel_buffs(lines, parser)


def _patch_channel_buffs(lines, parser):
    """Replay uniquely confirmed single-target channel gains in source order."""
    from utils.lua import parse_lua
    specs = {31833: (42484, 4), 3254: (3228, 5)}
    targets, pending, states, confirmed = {}, {}, {}, {}
    event = 0
    for line in lines:
        row = line.split("\t")
        if row[4] not in ("13", "21"):
            continue
        detail, frame = parse_lua(row[-1]), int(row[1])
        owner = detail[0]
        if row[4] == "21":
            event += 1
            if detail[2] != 0:
                continue
            for buff_id, (skill_id, _) in specs.items():
                if detail[4] == skill_id and detail[3] == 1:
                    key = (owner, buff_id)
                    targets.setdefault(key, set()).add(detail[1])
                    stack, end = states.get(key, (0, 0))
                    pending.setdefault(key, []).append(dict(
                        event=event, old=stack if end >= frame else 0,
                        target=detail[1], parent=buff_id == 31833,
                    ))
            if detail[4] == 3093 and len(casts := pending.get((owner, 3254), [])) == 1:
                casts[0]["parent"] = casts[0]["target"] == detail[1]
        elif detail[4] in specs:
            buff_id, stack, end = detail[4], detail[5], int(detail[6])
            key = (owner, buff_id)
            casts = pending.pop(key, [])
            limit = specs[buff_id][1]
            if detail[8] == 1 and end > frame and 1 <= stack <= limit and len(casts) == 1:
                cast = casts[0]
                if cast["parent"] and cast["old"] < limit and stack == cast["old"] + 1:
                    confirmed[cast["event"]] = (owner, buff_id, stack, end)
            states[key] = (stack, end) if detail[8] == 1 else (0, 0)

    original_parse_damage = parser.parse_damage
    event = 0

    def apply_grant(grant):
        owner, buff_id, stack, end = grant
        player = parser.players.get(owner)
        if (player and player.kungfu_id == 10225 and len(targets[(owner, buff_id)]) == 1
                and (buff_id == 3254 or 42472 in parser.select_talents[owner])):
            parser.buff_stacks[owner][buff_id][1] = stack
            parser.buff_intervals[owner][buff_id][1] = end

    def parse_damage(row):
        nonlocal event
        event += 1
        grant = confirmed.get(event)
        if grant and grant[1] == 3254:
            apply_grant(grant)
        result = original_parse_damage(row)
        if grant and grant[1] == 31833:
            apply_grant(grant)
        return result

    parser.parse_damage = parse_damage
