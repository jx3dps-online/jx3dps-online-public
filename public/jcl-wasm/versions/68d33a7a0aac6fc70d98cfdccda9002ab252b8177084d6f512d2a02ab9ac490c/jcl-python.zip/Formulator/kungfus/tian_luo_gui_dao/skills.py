from typing import Dict

from base.skill import Skill
from assets.skills import SKILLS as SKILL_ASSETS


class 心无旁骛(Skill):
    def record(self, actual_critical_strike, actual_damage, parser):
        super().record(actual_critical_strike, actual_damage, parser)
        凝气淬机 = 46138 in parser.select_talents[parser.current_player]
        聚精凝神 = 6451 in parser.select_talents[parser.current_player]
        parser.refresh_buff(8210 if 聚精凝神 else 3468, 2 if 凝气淬机 else 1, 1)
        parser.clear_buff(3468 if 聚精凝神 else 8210)
        if 凝气淬机:
            parser.refresh_buff(30721, 1, 1)


class 化血镖(Skill):
    def __post_init__(self):
        super().__post_init__()
        self.下一跳帧 = {}
        self.跨帧引爆候选 = {}

    def dot_add(self, parser):
        目标 = parser.current_target
        self.跨帧引爆候选.pop(目标, None)
        剩余跳数 = parser.current_dot_ticks.get(3221, 0)
        升级 = False
        同级刷新 = False
        if 剩余跳数 > 0:
            旧等级 = parser.current_dot_skills[3221][1]
            同级刷新 = 旧等级 == self.skill_level
            下一跳 = self.下一跳帧[目标]
            if 旧等级 <= 2 and self.skill_level == 旧等级 + 2:
                剩余跳数 *= 3
                距下一跳 = 下一跳 - parser.current_frame
                if 距下一跳 > 16:
                    剩余跳数 += 距下一跳 // 16
                    下一跳 = parser.current_frame + 距下一跳 % 16
                升级 = True
            elif 旧等级 % 2 == 1 and self.skill_level == 旧等级 + 1:
                升级 = True
        化血 = parser.current_kungfu.dots[3221]
        化血.buff_level = self.skill_level
        super().dot_add(parser)
        if 升级:
            parser.current_dot_ticks[3221] = 剩余跳数
        elif 同级刷新:
            if 化血.interval == 16:
                parser.current_dot_ticks[3221] += 1
        if 升级 or 同级刷新:
            self.下一跳帧[目标] = 下一跳
        else:
            self.下一跳帧[目标] = parser.current_frame + 化血.interval


class 千秋万劫(Skill):
    def dot_consume(self, parser):
        化血 = parser.current_kungfu.skills[3126]
        候选 = 化血.跨帧引爆候选.pop(parser.current_target, None)
        records = parser.current_last_dot.get(3221, [])
        if records:
            damage_tuple, status_tuple = records[-1]
            timeline = parser.current_records[damage_tuple][status_tuple]
            event = timeline[-1]
            frame = event[0]
            if frame == parser.current_frame - parser.start_frame:
                super().dot_consume(parser)
            elif (候选 and 候选[0] is event
                  and 0 < parser.current_frame - parser.start_frame - frame <= parser.CONTINUOUS_DELAY
                  and parser.current_dot_ticks[3221] == 候选[1] - 1):
                dot_tuple, dot_skill_tuple, _ = damage_tuple
                consumed = (dot_tuple, dot_skill_tuple, (self.skill_id, self.skill_level, 候选[1]))
                parser.current_records[consumed][status_tuple].append(timeline.pop())
                records.pop()
                parser.current_dot_ticks[3221] = 0


class 天女散花(Skill):
    def record(self, actual_critical_strike, actual_damage, parser):
        if parser.current_dot_ticks.get(3221, 0) > 0:
            parser.refresh_target_buff(-3393, 1, 1)
        super().record(actual_critical_strike, actual_damage, parser)
        parser.clear_target_buff(-3393, 1)


class 杀机断魂移除(Skill):
    final_buff = -24668

    def record(self, actual_critical_strike, actual_damage, parser):
        parser.clear_buff(self.final_buff, 1)


class 杀机断魂千机变(杀机断魂移除):
    def record(self, actual_critical_strike, actual_damage, parser):
        if buff_stack := parser.current_buff_stacks[24669].get(1):
            parser.refresh_buff(self.final_buff, 1, buff_stack)


class 杀机断魂天绝地灭(杀机断魂移除):
    def record(self, actual_critical_strike, actual_damage, parser):
        if parser.current_buff_stacks[16236].get(1):
            parser.refresh_buff(self.final_buff, 1, 6)
        elif parser.current_buff_stacks[16235].get(1):
            parser.refresh_buff(self.final_buff, 1, 4)
        elif parser.current_buff_stacks[16234].get(1):
            parser.refresh_buff(self.final_buff, 1, 2)


class 杀机断魂暗藏杀机(杀机断魂移除):
    def record(self, actual_critical_strike, actual_damage, parser):
        parser.refresh_buff(self.final_buff, 1, 3)


SKILLS: Dict[type, Dict[int, dict]] = {
    Skill: {
        # 通用
        3121: dict(channel_interval=16), 32885: {}, 6505: {},
        # 九宫飞星
        3105: dict(
            channel_interval=SKILL_ASSETS[3105]["channel_interval"][:26] + [470.5644350567163],
            poison_damage_base=SKILL_ASSETS[3105]["poison_damage_base"][:26] + [18],
            poison_damage_rand=SKILL_ASSETS[3105]["poison_damage_rand"][:26] + [2],
        ), 18776: {}, 3313: {}, 36502: {},
        3401: dict(channel_interval=306.7699635000001),
        3404: dict(channel_interval=540.4372974), 3819: dict(
            max_level=4, channel_interval=[415.90174626] * 3 + [415.90174626 * 1.6],
            poison_damage_base=[5, 13, 5, 10], poison_damage_rand=[0, 1, 0, 1],
        ),
        3824: dict(
            max_level=4, channel_interval=[745.8034704119999] * 3 + [745.8034704119999 * 1.6],
            poison_damage_base=[7, 19, 7, 15], poison_damage_rand=[0, 1, 0, 1],
        ), 3367: {},
        # 乾坤一掷
        3223: {}, 3228: dict(channel_interval=165.51009956250005),
        # 奇穴
        3304: dict(
            skill_name="化血迷心", max_level=1, kind_type="Physics", platform=0,
            channel_interval=388, poison_damage_call=1, poison_damage_base=2, poison_damage_rand=1,
        ),
        42484: dict(
            skill_name="天风汲雨", max_level=1, recipe_type=3108,
            kind_type="Physics", platform=0,
            channel_interval=184.14000000000001,
            poison_damage_call=1, poison_damage_base=1, poison_damage_rand=1,
        ),
        30894: {}, 30727: {}, 21266: dict(bind_dots={14611: 1}), 38760: dict(bind_dots=[{}, {29549: 1}]),

        26900: dict(channel_interval=451.871104452768),
        26901: dict(channel_interval=950.1560628708926), 15049: dict(post_buffs={10005: {1: 1}}), 31026: {}, 31027: {}, 28441: {},
        29687: dict(consume_dots={dot_id: (3, 3) for dot_id in (3221, 14611)}),
        # 装备
        25774: {}, 3480: dict(channel_interval=347.7723648, recipe_type=0),
        42664: dict(
            skill_name=["封喉", "星离雨散"], max_level=2,
            kind_type="Physics", platform=0, channel_interval=1536,
            poison_damage_call=1, poison_damage_base=[84, 112], poison_damage_rand=[10, 14],
        ),
    },
    千秋万劫: {
        18677: dict(consume_dots={3221: 0}, pve_addition=0, poison_damage_base=4, poison_damage_rand=4)
    },
    天女散花: {3393: {}},
    心无旁骛: {3094: {}},
    化血镖: {
        3126: dict(
            bind_dots={3221: 1},
            channel_interval=[382.9185360000001 * n for n in (1, 2, 3, 6)],
        )
    },
    杀机断魂移除: {33145: {}},
    杀机断魂千机变: {33142: {}},
    杀机断魂天绝地灭: {33143: {}},
    杀机断魂暗藏杀机: {33144: {}}
}
