from typing import Dict

from base.dot import Dot

class 化血(Dot):
    def parse(self, actual_critical_strike, actual_damage, parser):
        if self.buff_id not in parser.current_dot_skills:
            raise ValueError(
                f"化血缺少此前施加记录（玩家{parser.current_player}，目标{parser.current_target}，"
                f"帧{parser.current_frame}），无法还原快照；请使用包含施加过程的完整JCL"
            )
        化血镖 = parser.current_kungfu.skills[3126]
        下一跳 = 化血镖.下一跳帧[parser.current_target]
        剩余跳数 = parser.current_dot_ticks[self.buff_id]
        super().parse(actual_critical_strike, actual_damage, parser)
        旧候选 = 化血镖.跨帧引爆候选.pop(parser.current_target, None)
        # ConsumeBuff 的伤害与千秋本体可能跨日志帧；只保留明确早于自然跳的具体事件。
        if parser.current_frame + parser.CONTINUOUS_DELAY < 下一跳:
            key, status = parser.current_last_dot[self.buff_id][-1]
            event = parser.current_records[key][status][-1]
            化血镖.跨帧引爆候选[parser.current_target] = (None, 0) if 旧候选 else (event, 剩余跳数)
        化血镖.下一跳帧[parser.current_target] = parser.current_frame + self.interval


DOTS: Dict[type, Dict[int, dict]] = {
    化血: {
        3221: dict(interval=[48, 48, 16, 16], tick=[8, 8, 24, 24], damage_base=1),
    },
    Dot: {
        # 奇穴
        14611: {}, 29549: {}
    }
}
