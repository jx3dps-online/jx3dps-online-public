from typing import Dict

from base.buff import Buff

BUFFS: Dict[type, Dict[int, dict]] = {
    Buff: {
        -3393: dict(buff_name="命中化血目标伤害翻倍", attributes=dict(all_damage_cof=1024)),
        3254: {}, 3316: {}, 3468: dict(max_level=2),
        6112: dict(
            buff_name="千机之威",
            attributes=dict(physical_attack_power_gain=154, poison_attack_power_gain=154, all_shield_ignore=512),
        ),
        31833: dict(
            buff_name="天风汲雨", max_stack=4,
            attributes=dict(strain_gain=51, poison_overcome_gain=51),
        ),
        30721: dict(buff_name="专注", attributes=dict(all_damage_addition=102)),
        # 奇穴
        6105: {}, 23081: dict(buff_name="擘两分星"), 23082: dict(buff_name="擘两分星"), 8210: {},
        13165: dict(buff_name="雷甲三铉"), 27405: dict(buff_name="雷甲三铉"),
        -24668: dict(buff_name="杀机断魂"), 24669: {}, 16234: {}, 16235: {}, 16236: {}, 9981: {}, 10005: {},
    }
}
