from typing import Dict

from base.skill import Skill

SKILLS: Dict[type, Dict[int, dict]] = {
    Skill: {
        # 通用
        27451: dict(channel_interval=16), 32841: {}, 28081: {},
        # 行忌制方
        27552: {}, 27555: {}, 27560: dict(bind_dots={20052: 1}), 27557: {}, 27579: {}, 27584: {},
        # 凌波飞叶令
        28346: {}, 27539: {}, **{skill_id: dict(consume_dots=[{20052: 2}] * 31 + [{}]) for skill_id in (29505, 29506)},
        # 神农百草诀 / 凌波飞叶令扩展
        27657: {}, 28385: {}, 29535: {},
        # 秘传技能
        28430: {},
        # 奇穴
        40212: {}, 40208: {}, 28434: {}, 29674: dict(key_skill=True),
        28409: {}, 42444: {}, 36068: {}, 38638: {}, 28737: {},
        44392: {},
        # Generator assets/json/skills.json: 10627 -> 30734, level 1.
        30735: dict(
            skill_name="折枝拂露", kind_type="Poison", platform=0, max_level=1,
            channel_interval=337, poison_damage_base=73, poison_damage_rand=2,
            poison_damage_call=1,
            consume_dots={20052: 2},
        ),
        32922: dict(
            skill_name="折枝留春", kind_type="Poison", platform=0, max_level=1,
            channel_interval=1950, poison_damage_base=73, poison_damage_rand=2,
            poison_damage_call=1,
        ),
        38641: {}, 29441: {},
        29720: {}, 44992: {},
        # 装备
        29698: {}, 29695: {}
    }
}
