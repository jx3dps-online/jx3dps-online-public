from typing import Dict

from base.buff import Buff

BUFFS: Dict[type, Dict[int, dict]] = {
    Buff: {
        # 通用
        409: dict(attributes={"lunar_attack_power_gain": 154}),
        10240: dict(attributes={"lunar_critical_strike_rate": 800, "lunar_critical_power_rate": 21}),
        538: dict(
            attributes={"lunar_attack_power_gain": 461}, begin_frame_shift=-2,
            end_on_remove_event=True,
        ),
        # 奇穴
        5788: dict(attributes={"all_shield_ignore": 512}, max_stack=1),
        17010: dict(buff_name="广陵月"),
        25902: dict(max_stack=2),
        12549: dict(buff_name="元君"), 17969: {},
        25435: dict(attributes=[{}, {
            "lunar_critical_power_rate": 205,
            "lunar_critical_strike_rate": 500,
        }], begin_frame_shift=-2),
        30273: dict(
            buff_name="霜降", max_level=6, max_stack=1,
            recipes=[{5787: level} for level in range(1, 7)],
        ),
        30274: dict(buff_name="霜降"),
        12571: dict(buff_name="朝露", attributes={"lunar_attack_power_gain": 102}),
        **{
            buff_id: dict(
                buff_name=name, max_level=1, max_stack=1,
                recipes={28183: 1}, begin_frame_shift=-2,
                end_on_remove_event=True,
                dot_recipe_snapshot=False,
            )
            for buff_id, name in (
                (28183, "仙姿·剑破"), (28184, "仙姿·玳弦"),
                (28185, "仙姿·剑气"), (28186, "仙姿·剑影"),
            )
        },
    }
}
