from typing import Dict

from base.skill import Skill
from assets.skills import SKILLS as SKILL_ASSETS

SKILLS: Dict[type, Dict[int, dict]] = {
    Skill: {
        15: dict(channel_interval=21), 32957: {}, 34704: {}, 32889: {}, 34611: {},
        40289: dict(
            skill_name="霜降", channel_interval=[25, 31, 75, 100, 125, 200],
            lunar_damage_base=50, lunar_damage_rand=10,
            lunar_damage_call=1, lunar_surplus_call=0, global_damage_factor=0,
        ),
        # 猿公剑法
        40182: dict(
            channel_interval=913, lunar_damage_base=21, lunar_damage_rand=10,
            post_buffs={10240: {1: -1}},
        ),
        6234: dict(
            channel_interval=174.58638749999997, lunar_damage_base=25, lunar_damage_rand=2,
            post_buffs={10240: {1: -1}},
        ),
        30524: dict(
            channel_interval=727, lunar_damage_base=17, lunar_damage_rand=1,
            post_buffs={10240: {1: -1}},
        ),
        3889: dict(consume_dots={2920: 0}),
        **{
            skill_id: dict(
                bind_dots={2920: 1}, channel_interval=137.18133000000003,
                lunar_damage_base=1, lunar_damage_rand=0,
            ) for skill_id in (6207, 18716)
        },
        3009: {
            **SKILL_ASSETS[6207], "skill_name": "玳弦急曲", "bind_dots": {2920: 1},
            "channel_interval": 137.18133000000003, "lunar_damage_base": 1, "lunar_damage_rand": 0,
        },
        # 西河剑器
        6559: dict(
            channel_interval=366, lunar_damage_base=20, lunar_damage_rand=2,
            post_buffs={10240: {1: -1}},
        ),
        # 剑器浑脱
        568: dict(post_buffs={10240: {1: 5}}),
        # 奇穴
        6554: dict(
            channel_interval=77.4415333125, lunar_damage_base=11, lunar_damage_rand=0,
            post_buffs={10240: {1: -1}},
        ),
        **{
            skill_id: dict(channel_interval=coefficient, lunar_damage_base=75, lunar_damage_rand=0)
            for skill_id, coefficient in ((37317, 402), (37318, 69), (37319, 161), (37320, 598))
        },
        23936: dict(channel_interval=17, lunar_damage_base=2, lunar_damage_rand=1),
        33140: dict(channel_interval=[206, 412], lunar_damage_base=[75, 80], lunar_damage_rand=0),
        30532: dict(channel_interval=441, lunar_damage_base=13, lunar_damage_rand=1),
        24999: dict(
            channel_interval=121, lunar_damage_base=2, lunar_damage_rand=1,
            post_buffs={10240: {1: -1}},
        ),
        34612: {}, 35058: {},
        # 装备
        25769: {}, 25757: dict(bind_dots={18512: 1}),
    }
}
