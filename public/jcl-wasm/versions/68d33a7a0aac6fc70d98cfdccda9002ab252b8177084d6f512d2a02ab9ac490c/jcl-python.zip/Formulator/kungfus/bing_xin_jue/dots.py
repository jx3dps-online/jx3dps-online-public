from typing import Dict

from base.dot import Dot

DOTS: Dict[type, Dict[int, dict]] = {
    Dot: {
        2920: dict(max_stack=6, damage_base=1), 18512: {}
    }
}
