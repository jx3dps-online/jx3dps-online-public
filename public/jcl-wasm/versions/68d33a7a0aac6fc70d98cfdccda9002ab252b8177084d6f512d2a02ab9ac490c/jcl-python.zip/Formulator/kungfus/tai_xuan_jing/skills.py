from typing import Dict

from base.skill import Skill


class 九字诀(Skill):
    def damage(self, actual_critical_strike, actual_damage, parser):
        super().damage(actual_critical_strike, actual_damage, parser)
        if 37505 in parser.select_talents[parser.current_player] and actual_damage:
            分组 = (parser.current_frame, parser.current_target, self.recipe_type)
            记录 = (
                ((self.skill_id, self.skill_level), (), ()),
                parser.status,
                (parser.current_frame - parser.start_frame, actual_critical_strike, actual_damage),
            )
            parser.current_kungfu.镇星伤害记录.setdefault(分组, []).append(记录)


def 标记镇星复制(parser, player_id, target_id):
    伤害记录 = parser.records[player_id][target_id]
    for (_, 目标, 招式), 记录 in parser.players[player_id].镇星伤害记录.items():
        if (target_id and 目标 != target_id) or len(记录) != 2:
            continue
        # 同帧同目标的两次九字诀：临先本体后复制，兵、斗先复制后本体；兵可在两次之间切卦。
        技能, 状态, 时间点 = 记录[1 if 招式 == 24369 else 0]
        时间轴 = 伤害记录[技能][状态]
        时间轴.remove(时间点)
        if not 时间轴:
            del 伤害记录[技能][状态]
        复制状态 = (状态[0] + ((-28878, 1, 1),), 状态[1], 状态[2])
        伤害记录[技能].setdefault(复制状态, []).append(时间点)


SKILLS: Dict[type, Dict[int, dict]] = {
    九字诀: {
        24558: {}, **{skill_id: {} for skill_id in range(24675, 24677 + 1)},
        **{skill_id: {} for skill_id in range(24811, 24814 + 1)},
        **{skill_id: {} for skill_id in range(24821, 24824 + 1)},
    },
    Skill: {
        # 通用
        25512: dict(channel_interval=16), 32886: {},
        30026: dict(
            skill_name="往者定", kind_type="NeutralMagic", platform=0, recipe_type=24373,
            max_level=5, channel_interval=[20, 80, 95, 250, 250],
            neutral_damage_base=[3, 4, 4, 4, 4], neutral_damage_rand=[2, 3, 3, 3, 3],
            neutral_damage_call=1,
        ),
        42509: dict(
            skill_name="太白蚀昴", kind_type="NeutralMagic", platform=0,
            max_level=3, channel_interval=[260, 1071, 2772],
            neutral_damage_base=0, neutral_damage_rand=0, neutral_damage_call=1,
        ),
        # 占术
        24454: {}, 25031: {},
        # 奇门
        24870: {}, 25233: {}, 28815: {},
        # 奇穴
        30847: {}, 37311: {}, 34683: {}, 25174: {}, 37599: {},
        33236: {}, 42520: {}, 46458: {}, 46241: {},
        # 装备
        25837: {}, 33588: {},
    }
}
