from typing import Dict, List

from base.gain import Gain


TALENTS: List[Dict[int, Gain]] = [
    {
        5827: Gain("白虹", recipes=[(4092, 3)])
    },
    {
        5823: Gain("心固"),
    },
    {
        5846: Gain("无形", skill_ids=list(range(6091, 6100 + 1))),
        357: Gain("化三清"),
        33098: Gain("归衡"),
        34580: Gain("无外", skill_ids=[46142]),
    },
    {
        30821: Gain("绝云", skill_ids=[40158])
    },
    {
        5819: Gain("同尘", buff_ids=[9966])
    },
    {
        18695: Gain("跬步", buff_ids=list(range(12779, 12783 + 1)) + [-12550, -12551])
    },
    {
        32411: Gain("正气", skill_ids=[36438])
    },
    {
        14834: Gain("抱阳")
    },
    {
        18679: Gain("浮生", skill_ids=[18670])
    },
    {
        24945: Gain("破势", buff_ids=[-17918], skill_ids=[46296]),
        32412: Gain("星辰", skill_ids=[32414])
    },
    {
        23614: Gain("归元"),
        14836: Gain("自化", skill_ids=[20955])
    },
    {
        14613: Gain("固本"),
        36099: Gain("际地蟠天", skill_ids=[36102]),
        23969: Gain("剑出鸿蒙", skill_ids=[28590])
    }
]
