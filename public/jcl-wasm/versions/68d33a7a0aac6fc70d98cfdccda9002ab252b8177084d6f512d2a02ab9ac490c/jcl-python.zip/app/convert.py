import logging
import os
import sys
from collections import Counter
from typing import Dict, List, Optional, Set

_FORMULATOR_PATH = os.environ.get(
    "FORMULATOR_PATH",
    os.path.join(os.path.dirname(__file__), "..", "Formulator"),
)
_FORMULATOR_PATH = os.path.abspath(_FORMULATOR_PATH)

if _FORMULATOR_PATH not in sys.path:
    sys.path.insert(0, _FORMULATOR_PATH)

logger = logging.getLogger(__name__)

VALID_TARGET_LEVELS = frozenset({51, 52, 53, 54})

_WUFANG_LEVEL_NORMALIZE: Dict[int, Dict[int, int]] = {
    32841: {3: 2},
}

# These are activation/control records, not damage skills. The parser cannot
# turn them into output data, and their related buffs are tracked separately.
_INTERNAL_SKILL_IDS = frozenset({
    22169, 38578, 38934, 38944, 38945, 38950, 38984, 38985,
    39088, 40790, 40793, 40803,
})
_ONLINE_OWNED_BUFF_IDS = frozenset({15436, 15455})
_STACK_LEVEL_COMPOSITE_DOT_IDS = frozenset({20052})
_NILUAN_EXCLUDED_STATUS_BUFF_IDS = frozenset({20699})
_JUNZUO_BUFF_IDS = frozenset({34585, 34586})
_JUNZUO_DAMAGE_IDS = frozenset({28081, 27557, 27579})
_JUNZUO_END_SKILL_IDS = frozenset({27551, 27554, 29500})


def _get_normalized_level(skill_id: int, formulator_level: int) -> int:
    if skill_id in (3126, 3221, 3819, 3824, 33140, 40289, 22014, 38528, 40158, 46142, 25031, 42520, 46458, 46241, 42664):
        return formulator_level
    mapping = _WUFANG_LEVEL_NORMALIZE.get(skill_id, {})
    if mapping:
        return mapping.get(formulator_level, formulator_level)
    return 1


def _normalize_damage_display(display: str) -> str:
    paren_idx = display.rfind("(")
    if paren_idx != -1 and "#" in display[:paren_idx]:
        dot_part = display[:paren_idx]
        rest = display[paren_idx + 1:].rstrip(")")
        dot_name, dot_info = dot_part.split("#", 1)
        dot_id_str, dot_level_str, dot_rest = dot_info.split("-", 2)
        dot_id = int(dot_id_str)
        dot_level = int(dot_level_str)

        if "|" in rest:
            src_part, consume_part = rest.split("|", 1)
        else:
            src_part = rest
            consume_part = None

        src_name, src_info = src_part.split("#", 1)
        src_id_str, src_level_str, src_rest = src_info.split("-", 2)
        src_id = int(src_id_str)
        src_level = int(src_level_str)
        stack_level = None
        if dot_id in _STACK_LEVEL_COMPOSITE_DOT_IDS:
            try:
                stack_level = int(src_rest.split("-", 1)[0])
            except (ValueError, IndexError):
                pass
            new_src_level = stack_level if stack_level is not None else src_level
        else:
            new_src_level = _get_normalized_level(src_id, src_level)
        src_key = f"{src_name}#{src_id}-{new_src_level}-{src_rest}"

        # Niluan calculator level is the effective source stack count, not
        # Formulator internal DOT data level (10).
        if dot_id in _STACK_LEVEL_COMPOSITE_DOT_IDS:
            new_dot_level = stack_level if stack_level is not None else dot_level
        else:
            new_dot_level = _get_normalized_level(dot_id, dot_level)
        dot_key = f"{dot_name}#{dot_id}-{new_dot_level}-{dot_rest}"

        if consume_part:
            cons_name, cons_info = consume_part.split("#", 1)
            cons_id_str, cons_level_str, cons_rest = cons_info.split("-", 2)
            cons_id = int(cons_id_str)
            cons_level = int(cons_level_str)
            new_cons_level = _get_normalized_level(cons_id, cons_level)
            cons_key = f"{cons_name}#{cons_id}-{new_cons_level}-{cons_rest}"
            return f"{dot_key}({src_key}|{cons_key})"
        return f"{dot_key}({src_key})"

    name, info = display.split("#", 1)
    parts = info.split("-")
    skill_id = int(parts[0])
    level = int(parts[1]) if len(parts) > 1 else 1
    new_level = _get_normalized_level(skill_id, level)
    if new_level == 1:
        return f"{name}#{skill_id}"
    return f"{name}#{skill_id}-{new_level}"


def _normalize_status_display(
    display: str,
    excluded_buff_ids: frozenset[int] = frozenset(),
    装备属性Buff: frozenset[int] = _ONLINE_OWNED_BUFF_IDS,
) -> str:
    """Remove buffs that JX3ONLINE already models as equipment attributes."""
    sections = []
    for section in display.split("|"):
        tokens = []
        for token in section.split(",") if section else []:
            token = token.replace("破势#-17918-", "破势#17918-")
            token = token.replace("杀机断魂#-24668-", "杀机断魂#24668-")
            token = token.replace("命中化血目标伤害翻倍#-3393-", "命中化血目标伤害翻倍#3393-")
            token = token.replace("命中化血目标增伤#-42664-", "命中化血目标增伤#42664-")
            token = token.replace("镇星环#-28878-", "镇星环#28878-")
            try:
                buff_id = int(token.rsplit("#", 1)[1].split("-", 1)[0])
            except (IndexError, ValueError):
                tokens.append(token)
                continue
            if (
                buff_id not in 装备属性Buff
                and buff_id not in excluded_buff_ids
            ):
                tokens.append(token)
        sections.append(",".join(tokens))
    return "|".join(sections)


def _merge_status_detail(existing: dict, incoming: dict) -> None:
    old_count = existing["expected_count"]
    incoming_count = incoming["expected_count"]
    total_count = old_count + incoming_count
    existing["timeline"] += incoming["timeline"]
    if total_count:
        for field in (
            "hit_damage",
            "critical_damage",
            "critical_strike",
            "expected_damage",
        ):
            existing[field] = (
                existing[field] * old_count + incoming[field] * incoming_count
            ) / total_count
    existing["expected_count"] = total_count
    for key, value in incoming["gradients"].items():
        existing["gradients"][key] += value


def _copy_detail(detail) -> dict:
    detail_vars = vars(detail)
    copied = dict(detail_vars)
    copied["timeline"] = list(detail_vars["timeline"])
    copied["gradients"] = dict(detail_vars["gradients"])
    return copied



def _apply_paoyang(file_path: str, parser, player_id: str, target_id: str):
    paoyang_frames: Set[int] = set()
    try:
        lines = open(file_path, encoding="gbk").readlines()
    except UnicodeDecodeError:
        lines = open(file_path, encoding="utf-8").readlines()
    from utils.lua import parse_lua
    for line in lines:
        row = line.split("\t")
        if row[4] == "13":
            detail = parse_lua(row[-1])
            if detail[4] == 20718 and detail[5] == 0:
                paoyang_frames.add(int(row[1]) - parser.start_frame)

    if not paoyang_frames:
        return

    record = parser.records[player_id][target_id]
    for damage_tuple in list(record.keys()):
        if damage_tuple[0][0] != 28081:
            continue
        statuses = record[damage_tuple]
        new_statuses = {}
        for status_tuple, timeline in list(statuses.items()):
            pao_timeline = []
            rest_timeline = []
            for entry in timeline:
                nearby = any(pf - 2 <= entry[0] <= pf for pf in paoyang_frames)
                if nearby:
                    pao_timeline.append(entry)
                else:
                    rest_timeline.append(entry)
            if pao_timeline:
                current, snapshot, target_env = status_tuple
                pao_current = current
                if not any(buff_id == 20718 for buff_id, *_ in current):
                    pao_current = tuple(sorted(
                        list(current) + [(20718, 1, 1)],
                        key=lambda x: abs(x[0])
                    ))
                pao_status = (pao_current, snapshot, target_env)
                new_statuses[pao_status] = new_statuses.get(pao_status, []) + pao_timeline
            if rest_timeline:
                new_statuses.setdefault(status_tuple, []).extend(rest_timeline)
        if new_statuses:
            record[damage_tuple] = new_statuses


def _apply_wufang_junzuo(file_path: str, parser, player_id: str, target_id: str):
    """Restore consumed cast bonuses from the ordered Wufang JCL events."""
    try:
        lines = open(file_path, encoding="gbk").readlines()
    except UnicodeDecodeError:
        lines = open(file_path, encoding="utf-8").readlines()

    from utils.lua import parse_lua

    enhanced_signatures = Counter()
    junzuo_active = False
    chuan_until = None
    zhan_until = None

    def selected_target(detail):
        return not target_id or str(detail[1]) == str(target_id)

    for line in lines:
        row = line.split("\t")
        if row[4] not in ("13", "21"):
            continue
        detail = parse_lua(row[-1])
        if str(detail[0]) != str(player_id):
            continue

        frame = int(row[1])
        if row[4] == "13":
            buff_id, buff_stack, end_frame = detail[4], detail[5], int(detail[6])
            if buff_id == 34585:
                # Consumption precedes the cast's Zhonghe hits; natural expiry
                # does not grant a cast bonus. The first event may be removal.
                if buff_stack:
                    junzuo_active = False
                elif frame < end_frame:
                    junzuo_active = True
            elif buff_id == 34415:
                # The actual Chuanwu bonus persists after Chenshi is consumed.
                if buff_stack:
                    chuan_until = end_frame
                else:
                    chuan_until = None
            elif buff_id == 34549:
                # Zhanyi has its own delayed-damage bonus interval.
                if buff_stack:
                    zhan_until = end_frame
                else:
                    zhan_until = None
            continue

        damage_id = detail[4]
        if damage_id in _JUNZUO_END_SKILL_IDS:
            # These parent records follow all attached Zhonghe, even when the
            # cast produces no Zhonghe or its hits cross a frame boundary.
            junzuo_active = False
            continue
        if not selected_target(detail):
            continue
        if detail[2] != 0 or detail[3] != 1 or damage_id not in _JUNZUO_DAMAGE_IDS:
            continue

        actual_damage = detail[8].get(12, 0)
        if not actual_damage:
            continue

        is_enhanced = (
            (damage_id == 28081 and junzuo_active)
            or (damage_id == 27557 and chuan_until is not None and frame <= chuan_until)
            or (damage_id == 27579 and zhan_until is not None and frame <= zhan_until)
        )
        if is_enhanced:
            enhanced_signatures[
                (damage_id, detail[5], frame - parser.start_frame, detail[6], actual_damage)
            ] += 1

    record = parser.records[player_id][target_id]
    for damage_tuple in list(record.keys()):
        damage_id = damage_tuple[0][0]
        damage_level = damage_tuple[0][1]
        is_normal_skill = not damage_tuple[1] and damage_id in _JUNZUO_DAMAGE_IDS
        statuses = record[damage_tuple]
        new_statuses = {}
        for status_tuple, timeline in statuses.items():
            # Waiting buffs are not live global damage bonuses or DOT snapshots.
            cleaned_status = tuple(
                tuple(item for item in section if item[0] not in _JUNZUO_BUFF_IDS)
                for section in status_tuple
            )
            for entry in timeline:
                signature = (damage_id, damage_level, entry[0], entry[1], entry[2])
                enhanced = is_normal_skill and enhanced_signatures[signature] > 0
                if enhanced:
                    enhanced_signatures[signature] -= 1
                    buff_id = 34585 if damage_id == 28081 else 34586
                    current_status = tuple(sorted(
                        cleaned_status[0] + ((buff_id, 1, 1),),
                        key=lambda item: abs(item[0]),
                    ))
                    entry_status = (current_status, cleaned_status[1], cleaned_status[2])
                else:
                    entry_status = cleaned_status
                new_statuses.setdefault(entry_status, []).append(entry)
        record[damage_tuple] = new_statuses


class JclConvertError(Exception):
    pass


class _DiagnosticsCollector:
    def __init__(self):
        self.unknown_skill_ids_by_player: Dict[str, Set[int]] = {}
        self.unknown_buff_ids_by_player: Dict[str, Set[int]] = {}
        self.unknown_talent_ids: Set[int] = set()
        self.waist_enchant_players = set()


def _patch_parser_for_diagnostics(parser, collector: _DiagnosticsCollector):
    original_parse_damage = parser.parse_damage

    def patched_parse_damage(row):
        from utils.lua import parse_lua
        detail = parse_lua(row)
        caster_id = detail[0]
        player_id = (
            parser.pet2employer.get(caster_id, caster_id)
            if caster_id in parser.pet2employer
            else caster_id
        )
        if player_id not in parser.players:
            return
        target_id, react = detail[1], detail[2]
        if target_id not in parser.id2name or react:
            return original_parse_damage(row)
        damage_id = detail[4]
        player = parser.players[player_id]
        actual_damage = detail[8].get(12, 0)
        if (
            actual_damage
            and damage_id not in player.skills
            and damage_id not in player.dots
            and damage_id not in _INTERNAL_SKILL_IDS
        ):
            collector.unknown_skill_ids_by_player.setdefault(player_id, set()).add(int(damage_id))
        return original_parse_damage(row)

    original_parse_buff = parser.parse_buff

    def patched_parse_buff(row):
        from utils.lua import parse_lua
        detail = parse_lua(row)
        if detail[4] == 15455:
            collector.waist_enchant_players.add(parser.pet2employer.get(detail[0], detail[0]))
        owner_id = parser.pet2employer.get(detail[0], detail[0])
        if owner_id not in parser.players:
            owner_id = parser.pet2employer.get(detail[9], detail[9])
        if owner_id in parser.players:
            buff_id = detail[4]
            player = parser.players[owner_id]
            if buff_id and buff_id not in player.buffs and buff_id not in player.dots:
                collector.unknown_buff_ids_by_player.setdefault(owner_id, set()).add(int(buff_id))
        return original_parse_buff(row)

    parser.parse_damage = patched_parse_damage
    parser.parse_buff = patched_parse_buff


def convert_jcl(
    file_path: str,
    player_id: Optional[str] = None,
    target_id: str = "",
    target_level: int = 54,
    max_time: Optional[float] = None,
    min_time: float = 0,
) -> dict:
    from utils.parser import Parser
    from utils.analyzer import Analyzer
    from kungfus.tian_luo_gui_dao.jcl import patch_parser as patch_tianluo_parser

    if target_level not in VALID_TARGET_LEVELS:
        raise JclConvertError(
            f"Invalid target_level={target_level}. Supported: {sorted(VALID_TARGET_LEVELS)}"
        )

    if max_time is not None and max_time <= 0:
        raise JclConvertError(
            f"Invalid max_time={max_time}. It must be greater than zero."
        )

    diagnostics = _DiagnosticsCollector()

    parser = Parser()
    _patch_parser_for_diagnostics(parser, diagnostics)

    try:
        patch_tianluo_parser(file_path, parser)
        parser(file_path)
    except Exception as exc:
        raise JclConvertError(f"JCL parse failed: {exc}") from exc

    if not parser.players:
        raise JclConvertError(
            "No supported player found. Supported: Wufang (10627), Bingxin (10081), Zixia (10014), Taixuan (10615), Tianluo (10225)."
        )

    supported_players = {
        pid: p for pid, p in parser.players.items() if p.kungfu_id in (10627, 10081, 10014, 10615, 10225)
    }

    if not supported_players and player_id is None:
        raise JclConvertError("No Wufang (10627), Bingxin (10081), Zixia (10014) Taixuan (10615) or Tianluo (10225) player found in this log.")

    if player_id is None:
        player_id = next(iter(supported_players))
    else:
        player_id = next(
            (pid for pid in supported_players if str(pid) == str(player_id)),
            player_id,
        )
    if player_id not in parser.players:
        available = list(supported_players.keys())
        raise JclConvertError(
            f"Player {player_id!r} not found. Available supported players: {available}"
        )

    selected_player = parser.players[player_id]
    if selected_player.kungfu_id not in (10627, 10081, 10014, 10615, 10225):
        player_name = parser.id2name.get(player_id, str(player_id))
        raise JclConvertError(
            f"Selected player {player_name!r} is unsupported (kungfu={selected_player.kungfu_id}). "
            "Supported: Wufang (10627), Bingxin (10081), Zixia (10014), Taixuan (10615), Tianluo (10225)."
        )

    if player_id not in parser.id2name:
        raise JclConvertError(f"Player {player_id!r} has no recorded name in log.")

    parser.current_player = player_id
    parser.current_target = target_id

    if selected_player.kungfu_id == 10615 and target_id in parser.records[player_id]:
        from kungfus.tai_xuan_jing.skills import 标记镇星复制

        标记镇星复制(parser, player_id, target_id)

    used_buff_ids: Set[int] = set()
    for damage_tuple, statuses in parser.records.get(player_id, {}).get(target_id, {}).items():
        for status_tuple in statuses:
            for section in status_tuple:
                for buff_id, *_ in section:
                    used_buff_ids.add(buff_id)
    for buff_id in used_buff_ids:
        if buff_id in selected_player.buffs:
            selected_player.buffs[buff_id].activate = True

    talent_ids = parser.select_talents.get(player_id, [])

    if selected_player.kungfu_id == 10627 and 28458 in talent_ids and 20718 in selected_player.buffs:
        selected_player.buffs[20718].activate = True
        _apply_paoyang(file_path, parser, player_id, target_id)

    if target_id not in parser.records.get(player_id, {}):
        available_targets = list(parser.records.get(player_id, {}).keys())
        raise JclConvertError(
            f"Target {target_id!r} not found for player {player_id!r}. "
            f"Available targets: {available_targets}"
        )

    if 46224 in talent_ids:
        _apply_wufang_junzuo(file_path, parser, player_id, target_id)

    end_time = (
        min(max_time, parser.duration)
        if max_time is not None
        else parser.duration
    )
    record = parser.records[player_id][target_id]

    analyzer = Analyzer(
        kungfu=selected_player,
        target_level=target_level,
        start_time=min_time,
        end_time=end_time,
        record=record,
    )

    talent_keys = [(tid, 1) for tid in talent_ids]

    unknown_talent_ids = [
        int(tid)
        for tid in sorted(talent_ids)
        if (tid, 1) not in selected_player.gains
    ]

    valid_talent_keys = [
        key for key in talent_keys if key in selected_player.gains
    ]

    not_support_gains: List[str] = []
    try:
        not_support_gains = analyzer.add_gains(valid_talent_keys)
        analyzer.analyze_details()
        result: Dict[str, dict] = {}
        for damage_display, statuses in analyzer.details.items():
            norm_key = _normalize_damage_display(damage_display)
            damage_id = int(damage_display.split("#", 1)[1].split("-", 1)[0])
            excluded_buff_ids = (
                _NILUAN_EXCLUDED_STATUS_BUFF_IDS
                if damage_id in _STACK_LEVEL_COMPOSITE_DOT_IDS
                else frozenset()
            )
            # Analyzer's empty key is an aggregate. Keep it only when it is
            # the sole status; otherwise it would duplicate every timeline.
            status_items = [
                (status_display, detail)
                for status_display, detail in statuses.items()
                if status_display or not any(statuses)
            ]
            output_statuses = result.setdefault(norm_key, {})
            for status_display, detail in status_items:
                norm_status = _normalize_status_display(
                    status_display,
                    excluded_buff_ids=excluded_buff_ids,
                    装备属性Buff=(
                        _ONLINE_OWNED_BUFF_IDS - {15455}
                        if selected_player.kungfu_id in (10225, 10615)
                        else _ONLINE_OWNED_BUFF_IDS
                    ),
                )
                detail_vars = _copy_detail(detail)
                if norm_status in output_statuses:
                    _merge_status_detail(output_statuses[norm_status], detail_vars)
                else:
                    output_statuses[norm_status] = detail_vars
    finally:
        analyzer.sub_gains()
        analyzer.sub_recipes()

    unknown_skill_ids = sorted(
        diagnostics.unknown_skill_ids_by_player.get(player_id, set())
        | {
            int(sid)
            for sid in not_support_gains
            if sid.lstrip("-").isdigit()
        }
    )
    unknown_buff_ids = sorted(diagnostics.unknown_buff_ids_by_player.get(player_id, set()))

    for statuses in result.values():
        for detail in statuses.values():
            timeline = detail["timeline"]
            hits = [point[2] for point in timeline if not point[1]]
            criticals = [point[2] for point in timeline if point[1]]
            detail["actual_hit_damage"] = sum(hits) / len(hits) if hits else None
            detail["actual_critical_damage"] = sum(criticals) / len(criticals) if criticals else None
            detail["actual_critical_strike"] = len(criticals) / len(timeline) if timeline else 0
            detail["actual_damage"] = sum(point[2] for point in timeline) / len(timeline) if timeline else 0

    return {
        # Only Tianluo opts into full-log, player-owned waist coverage.
        "waistEnchantObserved": (
            player_id in diagnostics.waist_enchant_players
            if selected_player.kungfu_id == 10225
            else False
        ),
        "player": {
            "id": str(player_id),
            "name": parser.id2name[player_id],
            "kungfuId": selected_player.kungfu_id,
            "kungfuName": selected_player.name,
        },
        "battle": {
            "startFrame": parser.start_frame,
            "endFrame": parser.end_frame,
            "analysisSeconds": max(0.0, float(end_time - min_time)),
        },
        "data": result,
        "diagnostics": {
            "unknownSkillIds": unknown_skill_ids,
            "unknownBuffIds": unknown_buff_ids,
            "unknownTalentIds": unknown_talent_ids,
        },
    }
